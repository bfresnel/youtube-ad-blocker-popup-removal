#/bin/bash

zip -r ads-youtube.zip .